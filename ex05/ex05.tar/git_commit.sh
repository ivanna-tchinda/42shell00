git log --pretty="format: %H"
